package th.smp.plugin;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

/* ====================================================================
 *  SmpPlugin : /smp skin | nick | ui + ระบบตายแล้วโดนเตะ
 * ==================================================================== */
public class SmpPlugin extends JavaPlugin implements Listener {

    private boolean deathKick;
    private int deathSound;

    // เก็บค่าเดิมไว้ใช้ตอน reset
    private final Map<UUID, ProfileProperty> originalSkins = new HashMap<>();
    private final Map<UUID, String> originalNames = new HashMap<>();

    @Override
    public void onEnable() {
        // ค่าเริ่มต้น (สร้าง config.yml ให้อัตโนมัติ)
        getConfig().addDefault("death-kick", false);   // เปิด/ปิด ตายแล้วโดนเตะ
        getConfig().addDefault("death-sound", 1);      // 0=ไม่มีเสียง 1=Wither 2=Elder Guardian 3=Wither ทุ้ม
        getConfig().addDefault("sound-range", 310.0);  // ระยะที่ได้ยินเสียง (บล็อก)
        getConfig().options().copyDefaults(true);
        saveConfig();
        deathKick = getConfig().getBoolean("death-kick", false);
        deathSound = getConfig().getInt("death-sound", 1);

        SmpCommand cmd = new SmpCommand(this);
        getCommand("smp").setExecutor(cmd);
        getCommand("smp").setTabCompleter(cmd);

        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getPluginManager().registerEvents(new SmpMenu.MenuListener(this), this);
        Bukkit.getPluginManager().registerEvents(new DeathListener(this), this);

        for (Player p : Bukkit.getOnlinePlayers()) rememberOriginal(p);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        rememberOriginal(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        originalSkins.remove(e.getPlayer().getUniqueId());
        originalNames.remove(e.getPlayer().getUniqueId());
    }

    private void rememberOriginal(Player p) {
        originalNames.putIfAbsent(p.getUniqueId(), p.getName());
        p.getPlayerProfile().getProperties().stream()
                .filter(pp -> pp.getName().equals("textures"))
                .findFirst()
                .ifPresent(pp -> originalSkins.putIfAbsent(p.getUniqueId(), pp));
    }

    public ProfileProperty getOriginalSkin(Player p) {
        return originalSkins.get(p.getUniqueId());
    }

    public String getOriginalName(Player p) {
        return originalNames.getOrDefault(p.getUniqueId(), p.getName());
    }

    public double getSoundRange() {
        return getConfig().getDouble("sound-range", 310.0);
    }

    public boolean isDeathKick() {
        return deathKick;
    }

    public void setDeathKick(boolean value) {
        this.deathKick = value;
        getConfig().set("death-kick", value);
        saveConfig();
    }

    public int getDeathSound() {
        return deathSound;
    }

    public void setDeathSound(int value) {
        this.deathSound = value;
        getConfig().set("death-sound", value);
        saveConfig();
    }
}

/* ====================================================================
 *  ระบบตาย: เล่นเสียง + เตะ (รวม OP)
 * ==================================================================== */
class DeathListener implements Listener {

    private final SmpPlugin plugin;

    public DeathListener(SmpPlugin plugin) {
        this.plugin = plugin;
    }

    /** เล่นเสียงตามโหมดให้ผู้เล่นคนนั้น (เล่นที่ตำแหน่งผู้ฟัง เพื่อให้ได้ยินชัดแม้ไกล) */
    public static void playDeathSound(int mode, Player listener) {
        Location loc = listener.getLocation();
        switch (mode) {
            // 1: เสียง Wither ตอนเกิด
            case 1 -> listener.playSound(loc, Sound.ENTITY_WITHER_SPAWN, 1.0f, 1.0f);
            // 2: เสียง Elder Guardian ตอนมีเอฟเฟกต์ขึ้นจอ (เฉพาะเสียง ไม่มีภาพ)
            case 2 -> listener.playSound(loc, Sound.ENTITY_ELDER_GUARDIAN_CURSE, 1.0f, 1.0f);
            // 3: เสียง Wither แบบต่ำ ทุ้ม (pitch ต่ำสุด)
            case 3 -> listener.playSound(loc, Sound.ENTITY_WITHER_SPAWN, 1.0f, 0.5f);
            default -> { }
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (!plugin.isDeathKick()) return;

        Player dead = e.getEntity();

        // ผู้เล่นที่อยู่ในโลกเดียวกันและห่างจากจุดตายไม่เกิน 310 บล็อก (ตั้งได้ใน config: sound-range)
        int mode = plugin.getDeathSound();
        Location deathLoc = dead.getLocation();
        double range = plugin.getSoundRange();
        double rangeSq = range * range;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!p.getWorld().equals(deathLoc.getWorld())) continue;
            if (p.getLocation().distanceSquared(deathLoc) <= rangeSq) {
                playDeathSound(mode, p);
            }
        }

        // เตะทุกคนที่ตาย รวมถึง OP ด้วย
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (dead.isOnline()) {
                dead.kick(Component.text("You died and were banned from the server", NamedTextColor.RED));
            }
        }, 1L);
    }
}

/* ====================================================================
 *  เมนู /smp ui
 * ==================================================================== */
class SmpMenu implements InventoryHolder {

    private static final int SLOT_TOGGLE = 4;
    private static final int SLOT_SOUND_1 = 11;
    private static final int SLOT_SOUND_2 = 13;
    private static final int SLOT_SOUND_3 = 15;
    private static final int SLOT_SOUND_OFF = 22;
    private static final int SLOT_CLOSE = 26;

    private final SmpPlugin plugin;
    private final Inventory inv;

    public SmpMenu(SmpPlugin plugin) {
        this.plugin = plugin;
        this.inv = Bukkit.createInventory(this, 27,
                Component.text("SMP Menu", NamedTextColor.DARK_PURPLE));
        render();
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inv;
    }

    public void open(Player p) {
        p.openInventory(inv);
    }

    private static ItemStack item(Material m, String name, NamedTextColor color, List<Component> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        if (lore != null) meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private static Component lore(String s, NamedTextColor c) {
        return Component.text(s, c).decoration(TextDecoration.ITALIC, false);
    }

    private void render() {
        inv.clear();

        // ปุ่มเปิด/ปิด ตายแล้วโดนเตะ
        boolean on = plugin.isDeathKick();
        inv.setItem(SLOT_TOGGLE, item(
                on ? Material.LIME_DYE : Material.GRAY_DYE,
                "ตายแล้วโดนเตะออกจากเซิร์ฟ: " + (on ? "เปิด" : "ปิด"),
                on ? NamedTextColor.GREEN : NamedTextColor.RED,
                List.of(lore("คลิกเพื่อสลับ เปิด/ปิด", NamedTextColor.GRAY))));

        int s = plugin.getDeathSound();
        inv.setItem(SLOT_SOUND_1, sound(1, s, "เสียง 1: Wither Spawn", Material.WITHER_SKELETON_SKULL));
        inv.setItem(SLOT_SOUND_2, sound(2, s, "เสียง 2: Elder Guardian", Material.PRISMARINE_SHARD));
        inv.setItem(SLOT_SOUND_3, sound(3, s, "เสียง 3: Wither ทุ้มต่ำ", Material.NETHER_STAR));

        inv.setItem(SLOT_SOUND_OFF, item(
                s == 0 ? Material.BARRIER : Material.STRUCTURE_VOID,
                "ไม่มีเสียง" + (s == 0 ? " (เลือกอยู่)" : ""),
                NamedTextColor.RED, null));

        inv.setItem(SLOT_CLOSE, item(Material.RED_STAINED_GLASS_PANE, "ปิดเมนู", NamedTextColor.RED, null));
    }

    private ItemStack sound(int id, int selected, String name, Material m) {
        boolean sel = id == selected;
        ItemStack it = item(m, name + (sel ? " ✔" : ""),
                sel ? NamedTextColor.GREEN : NamedTextColor.YELLOW,
                List.of(lore("คลิกซ้าย: เลือกเสียงนี้", NamedTextColor.GRAY),
                        lore("คลิกขวา: ฟังตัวอย่าง", NamedTextColor.GRAY)));
        if (sel) {
            ItemMeta meta = it.getItemMeta();
            meta.setEnchantmentGlintOverride(true);
            it.setItemMeta(meta);
        }
        return it;
    }

    public static class MenuListener implements Listener {
        private final SmpPlugin plugin;

        public MenuListener(SmpPlugin plugin) {
            this.plugin = plugin;
        }

        @EventHandler
        public void onClick(InventoryClickEvent e) {
            if (!(e.getView().getTopInventory().getHolder() instanceof SmpMenu menu)) return;
            e.setCancelled(true);
            if (e.getClickedInventory() != e.getView().getTopInventory()) return;
            if (!(e.getWhoClicked() instanceof Player p)) return;
            if (!p.hasPermission("smp.ui")) return;

            int slot = e.getSlot();
            boolean right = e.isRightClick();

            switch (slot) {
                case SLOT_TOGGLE -> plugin.setDeathKick(!plugin.isDeathKick());
                case SLOT_SOUND_1, SLOT_SOUND_2, SLOT_SOUND_3 -> {
                    int id = slot == SLOT_SOUND_1 ? 1 : slot == SLOT_SOUND_2 ? 2 : 3;
                    if (right) {
                        DeathListener.playDeathSound(id, p); // แค่ฟังตัวอย่าง
                        return;
                    }
                    plugin.setDeathSound(id);
                    DeathListener.playDeathSound(id, p);
                }
                case SLOT_SOUND_OFF -> plugin.setDeathSound(0);
                case SLOT_CLOSE -> {
                    p.closeInventory();
                    return;
                }
                default -> {
                    return;
                }
            }
            menu.render();
        }

        @EventHandler
        public void onDrag(InventoryDragEvent e) {
            if (e.getView().getTopInventory().getHolder() instanceof SmpMenu) {
                e.setCancelled(true);
            }
        }
    }
}

/* ====================================================================
 *  คำสั่ง /smp skin | nick | ui
 * ==================================================================== */
class SmpCommand implements CommandExecutor, TabCompleter {

    private static final Pattern VALID_NAME = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8)).build();

    // รายชื่อสกินสุ่ม (ชื่อบัญชี Minecraft ที่มีอยู่จริง ใช้ดึงสกินจาก Mojang เหมือนที่แสดงใน NameMC)
    private static final String[] RANDOM_SKINS = {
            "Notch", "jeb_", "Dinnerbone", "Technoblade", "Dream", "GeorgeNotFound",
            "Sapnap", "TommyInnit", "Tubbo_", "Philza", "Ranboo", "Skeppy",
            "BadBoyHalo", "Wilbur_Soot", "Quackity", "CaptainSparklez", "Grian", "Mumbo_Jumbo"
    };

    private static final String[] ADJ = {
            "Swift", "Shadow", "Cosmic", "Silent", "Frozen", "Crimson", "Lucky", "Mystic",
            "Brave", "Wild", "Ender", "Pixel", "Golden", "Dark", "Neon", "Sneaky"
    };
    private static final String[] NOUN = {
            "Wolf", "Creeper", "Fox", "Ninja", "Dragon", "Knight", "Panda", "Ghost",
            "Miner", "Slime", "Phantom", "Hunter", "Warden", "Axolotl", "Blaze", "Steve"
    };

    private final SmpPlugin plugin;

    public SmpCommand(SmpPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("คำสั่งนี้ใช้ได้เฉพาะผู้เล่น");
            return true;
        }
        if (args.length == 0) {
            usage(player);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "skin" -> {
                if (!player.hasPermission("smp.skin")) { noPerm(player); return true; }
                if (args.length < 2) {
                    msg(player, "ใช้: /smp skin <ชื่อสกิน|random|reset>", NamedTextColor.YELLOW);
                    return true;
                }
                handleSkin(player, args[1]);
            }
            case "nick" -> {
                if (!player.hasPermission("smp.nick")) { noPerm(player); return true; }
                if (args.length < 2) {
                    msg(player, "ใช้: /smp nick <ชื่อ|random|reset>", NamedTextColor.YELLOW);
                    return true;
                }
                handleNick(player, args);
            }
            case "ui" -> {
                if (!player.hasPermission("smp.ui")) { noPerm(player); return true; }
                new SmpMenu(plugin).open(player);
            }
            default -> usage(player);
        }
        return true;
    }

    // ---------------------------------------------------------------- SKIN

    private void handleSkin(Player player, String arg) {
        if (arg.equalsIgnoreCase("reset")) {
            ProfileProperty original = plugin.getOriginalSkin(player);
            if (original == null) {
                msg(player, "ไม่พบสกินเดิมของคุณ", NamedTextColor.RED);
                return;
            }
            applySkin(player, original);
            msg(player, "คืนสกินเดิมแล้ว", NamedTextColor.GREEN);
            return;
        }

        final String skinName = arg.equalsIgnoreCase("random")
                ? RANDOM_SKINS[ThreadLocalRandom.current().nextInt(RANDOM_SKINS.length)]
                : arg;

        if (!VALID_NAME.matcher(skinName).matches()) {
            msg(player, "ชื่อสกินไม่ถูกต้อง", NamedTextColor.RED);
            return;
        }

        msg(player, "กำลังดึงสกิน " + skinName + " ...", NamedTextColor.GRAY);

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                ProfileProperty prop = fetchSkin(skinName);
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!player.isOnline()) return;
                    if (prop == null) {
                        msg(player, "ไม่พบผู้เล่นชื่อ " + skinName, NamedTextColor.RED);
                        return;
                    }
                    applySkin(player, prop);
                    msg(player, "เปลี่ยนสกินเป็น " + skinName + " แล้ว", NamedTextColor.GREEN);
                });
            } catch (Exception ex) {
                Bukkit.getScheduler().runTask(plugin, () ->
                        msg(player, "ดึงสกินไม่สำเร็จ (ลองใหม่ภายหลัง)", NamedTextColor.RED));
                plugin.getLogger().warning("Skin fetch failed: " + ex.getMessage());
            }
        });
    }

    private void applySkin(Player player, ProfileProperty prop) {
        PlayerProfile profile = player.getPlayerProfile();
        profile.setProperty(prop);
        player.setPlayerProfile(profile);
    }

    /** ดึงสกินจาก Mojang API (NameMC ใช้ข้อมูลชุดเดียวกัน) */
    private ProfileProperty fetchSkin(String name) throws Exception {
        HttpResponse<String> r1 = HTTP.send(HttpRequest.newBuilder(
                URI.create("https://api.mojang.com/users/profiles/minecraft/" + name))
                .timeout(Duration.ofSeconds(8)).build(), HttpResponse.BodyHandlers.ofString());
        if (r1.statusCode() != 200) return null;

        String id = JsonParser.parseString(r1.body()).getAsJsonObject().get("id").getAsString();

        HttpResponse<String> r2 = HTTP.send(HttpRequest.newBuilder(
                URI.create("https://sessionserver.mojang.com/session/minecraft/profile/" + id + "?unsigned=false"))
                .timeout(Duration.ofSeconds(8)).build(), HttpResponse.BodyHandlers.ofString());
        if (r2.statusCode() != 200) return null;

        JsonArray props = JsonParser.parseString(r2.body()).getAsJsonObject().getAsJsonArray("properties");
        for (JsonElement el : props) {
            JsonObject o = el.getAsJsonObject();
            if (o.get("name").getAsString().equals("textures")) {
                String value = o.get("value").getAsString();
                String sig = o.has("signature") ? o.get("signature").getAsString() : null;
                return new ProfileProperty("textures", value, sig);
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- NICK

    private void handleNick(Player player, String[] args) {
        // รวมทุกคำหลัง "nick" เป็นชื่อเดียว
        String joined = String.join(" ", Arrays.copyOfRange(args, 1, args.length));

        if (joined.equalsIgnoreCase("reset")) {
            applyNick(player, plugin.getOriginalName(player));
            msg(player, "คืนชื่อเดิมแล้ว", NamedTextColor.GREEN);
            return;
        }

        String nick = joined.equalsIgnoreCase("random") ? randomNick() : joined;

        if (nick.isBlank()) {
            msg(player, "กรุณาใส่ชื่อ", NamedTextColor.RED);
            return;
        }
        if (nick.length() > 16) {
            msg(player, "ชื่อยาวได้สูงสุด 16 ตัวอักษร (ข้อจำกัดของ Minecraft)", NamedTextColor.RED);
            return;
        }
        if (nick.chars().anyMatch(ch -> ch < 32 || ch == 127 || ch == '\u00a7')) {
            msg(player, "ชื่อมีอักขระที่ใช้ไม่ได้", NamedTextColor.RED);
            return;
        }
        Player other = Bukkit.getPlayerExact(nick);
        if (other != null && !other.equals(player)) {
            msg(player, "มีผู้เล่นใช้ชื่อนี้อยู่แล้ว", NamedTextColor.RED);
            return;
        }

        applyNick(player, nick);
        msg(player, "เปลี่ยนชื่อเป็น " + nick + " แล้ว", NamedTextColor.GREEN);
    }

    /** เปลี่ยนชื่อจริงใน profile ทำให้ป้ายชื่อ แชท Tab คำสั่ง ใช้ชื่อใหม่ทั้งหมด วาร์ป/ตายแล้วก็ไม่หาย */
    private void applyNick(Player player, String nick) {
        PlayerProfile profile = player.getPlayerProfile();
        profile.setName(nick);
        player.setPlayerProfile(profile);
        player.displayName(Component.text(nick));
        player.playerListName(Component.text(nick));
    }

    private String randomNick() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        String n = ADJ[r.nextInt(ADJ.length)] + NOUN[r.nextInt(NOUN.length)] + r.nextInt(10, 100);
        return n.length() > 16 ? n.substring(0, 16) : n;
    }

    // ---------------------------------------------------------------- UTIL

    private void usage(Player p) {
        msg(p, "/smp skin <ชื่อ|random|reset>", NamedTextColor.YELLOW);
        msg(p, "/smp nick <ชื่อ|random|reset>", NamedTextColor.YELLOW);
        msg(p, "/smp ui", NamedTextColor.YELLOW);
    }

    private void noPerm(Player p) {
        msg(p, "คุณไม่มีสิทธิ์ใช้คำสั่งนี้", NamedTextColor.RED);
    }

    private void msg(Player p, String text, NamedTextColor color) {
        p.sendMessage(Component.text("[SMP] ", NamedTextColor.DARK_PURPLE)
                .append(Component.text(text, color)));
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("skin", "nick", "ui"))
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("skin") || args[0].equalsIgnoreCase("nick"))) {
            for (String s : List.of("random", "reset"))
                if (s.startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(s);
        }
        return out;
    }
}
